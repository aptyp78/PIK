# Canvases-as-Code

Канвасы описываются в YAML по общей схеме (`schema/canvas.schema.json`).

## Как читать YAML
- `canvas_type`: тип канваса (ecosystem_forces | platform_opportunity | ...)
- `sections`: блоки канваса с полями
- `agent`: инструкция для LLM как обработать данные

## Советы по генерации отчётов
- Для каждого канваса держи рядом соответствующий агент в `agents/`.
- Копируй YAML + инструкцию агента в ChatGPT → полученный Markdown сохраняй в `docs/reports/` и публикуй через Pages.
