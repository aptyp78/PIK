# PIK Platform

Добро пожаловать. Здесь хранятся канвасы как данные, отчёты и примеры применения на кейсе **Банк ПСБ**.

> Идея: канвас — это программа (агент). YAML → агент → отчёт/решение.

**Навигация**
- [Canvases](./canvases.md)
- [PSB Use Case](./cases/psb/overview.md)
- [Ontology](./ontology.md)
