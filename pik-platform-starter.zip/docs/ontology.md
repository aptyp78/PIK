# Ontology (beta)

Мини-онтология PIK для унификации терминов и связей (Canvas, Section, Field, Stakeholder, ValueFlow, NetworkEffect).

Исходник: [`ontology/pik.ttl`](../ontology/pik.ttl).
