# PIK Platform — Dynamic Methodology

Эта платформа — «методология как код»: канвасы PIK описываются в YAML по единой схеме, валидируются CI, автоматически собираются в сайт (GitHub Pages) и дополняются отчётами.

### Быстрый старт (без программирования)
1. Создай репозиторий из этого шаблона (**Use this template**) или скопируй файлы.
2. Включи **Settings → Pages → Build and deployment → Source: GitHub Actions**.
3. Измени `docs/index.md` под свой проект.
4. Заполни один из примеров в папке `canvases/` и закомить — сайт обновится автоматически.

### Опционально: генерация отчётов агентом
Пока без автоматизации. Самый простой путь — открыть `agents/ecosystem_forces_agent.yaml` и **скопировать инструкцию** в ChatGPT вместе с YAML канваса. Полученный отчёт вставь в `docs/reports/` (создай папку) и закомить.

При желании можно позже добавить шаг GitHub Actions для генерации отчётов (потребуется `OPENAI_API_KEY`).

### Что внутри
- **canvases/** — канвасы как данные (YAML)
- **schema/** — JSON Schema единого формата канвасов
- **agents/** — описания «агентов канвасов» (prompt-спеки)
- **docs/** — сайт MkDocs Material
- **ontology/** — минимальная онтология PIK (OWL/Turtle)
- **tools/** — скрипты валидации (запускаются GitHub Actions)

### Как создавать новый канвас
- Создай issue по шаблону **New Canvas** → при закрытии issue добавь YAML в `canvases/`.
- Или скопируй существующий YAML и измени поля.

### Примерная логика PIK (с привязкой к ПСБ)
- Phase 01 — **Ecosystemize**: скан факторов экосистемы, выбор полей роста.
- Phase 02 — **Explore**: канвас Platform Opportunity, гипотезы ценности.
- Phase 03 — **Design**: Platform Business Model, механизм сетевых эффектов.
- Phase 04 — **Build/Scale**: Architecture Canvas, Governance, Growth.

### Лицензия
MIT (адаптируй под себя).
