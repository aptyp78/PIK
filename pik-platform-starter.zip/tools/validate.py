import json, sys, pathlib, yaml
from jsonschema import Draft202012Validator

root = pathlib.Path(__file__).resolve().parents[1]
schema = json.loads((root / 'schema' / 'canvas.schema.json').read_text(encoding='utf-8'))
errors = []
for p in (root / 'canvases').glob('*.yaml'):
    data = yaml.safe_load(p.read_text(encoding='utf-8'))
    v = Draft202012Validator(schema)
    for e in sorted(v.iter_errors(data), key=str):
        errors.append(f"{p.name}: {e.message}")
if errors:
    print("\n".join(errors))
    sys.exit(1)
print("All canvases valid ✅")
